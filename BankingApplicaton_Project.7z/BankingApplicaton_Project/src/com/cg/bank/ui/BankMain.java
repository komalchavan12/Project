package com.cg.bank.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.BankServiceImpl;
import com.cg.bank.service.IBankService;

public class BankMain {
	public static void main(String[] args) throws BankException {
		Scanner scan=null;
		Scanner scan1=null;
		IBankService service= new BankServiceImpl();
		Account account=null;
		String ContinueChoice="";
		do {
			System.out.println("******** Welcome to Mobile App *********");	
			System.out.println("*******************************");
			System.out.println("1.Create Account\n2.Show Balance\n3.Deposite\n4.Withdraw\n5.Fund Transfer\n6.Print Transaction");
			System.out.println("*******************************");
			
			int choice =0;
			boolean choiceFlag=false;
			do {
				scan=new Scanner(System.in);
				System.out.println("Enter your Choice");
				try {
					choice=scan.nextInt();
					choiceFlag=true;
					switch(choice) {
					case 1:
				             	String Username="";
									boolean UsernameFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Username");
										try {
										Username=scan1.nextLine();
										service.validateUserName(Username);	
										UsernameFlag=true;
										break;
										}catch(BankException e) {
											UsernameFlag=false;
											System.out.println(e.getMessage());
										}
									}while(!UsernameFlag);
									String Password="";
									boolean PasswordFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Password");
										try {
										Password=scan1.nextLine();
										service.validatePassword(Password);	
										PasswordFlag=true;
										break;
										}catch(BankException e) {
											PasswordFlag=false;
											System.out.println(e.getMessage());
										}
									}while(!PasswordFlag);
									String MobileNo="";
									boolean  MobileNoFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Mobile number");
										try {
											 MobileNo=scan1.nextLine();
										service.validateMobileNo(MobileNo);	
										 MobileNoFlag=true;
										break;
										}catch(BankException e) {
											 MobileNoFlag=false;
											System.out.println(e.getMessage());
										}
									}while(! MobileNoFlag);
									
									int Account_number=(int) (Math.random()*1000*1000);
									//account.setAccount_number(Account_number);
									System.out.println("Account created Successfully with Account number"+ Account_number);
									break;
								case 2:
									int Account_number1 = 0;
									boolean Account_numberFlag = false;
									do {
										scan = new Scanner(System.in);
										System.out.println("Enter Account number");
										try {
											Account_number1 = scan.nextInt();
											service.validateAccount_number(Account_number1);
											System.out.println(service.ShowBalance());
											Account_numberFlag = true;
											break;

										} catch (InputMismatchException e) {
											Account_numberFlag = false;
											System.err.println(e.getMessage());
										} catch (BankException e) {
											System.err.println(e.getMessage());
										}

									} while (!Account_numberFlag);
									break;
								
				
						
						
					
					}
					
				}catch(InputMismatchException e) {
					choiceFlag=false;
					System.err.println("Please Enter digits");
				}
				
			}while(!choiceFlag);
			scan=new Scanner(System.in);
			System.out.println("Do you want to continue again [yes/no]");
			ContinueChoice=scan.nextLine();
			
		}while(ContinueChoice.equalsIgnoreCase("yes"));
		scan.close();
		scan1.close();
		
	}

}
