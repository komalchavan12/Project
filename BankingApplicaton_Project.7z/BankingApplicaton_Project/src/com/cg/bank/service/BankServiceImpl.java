package com.cg.bank.service;

import java.util.regex.Pattern;

import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.dao.IBankDAO;
import com.cg.bank.exception.BankException;


public class BankServiceImpl implements IBankService {
	IBankDAO dao=new BankDAOImpl();

	@Override
	public void validateUserName(String username) throws BankException {
		String NameRegex="[A-Z]{1}[a-z]{2,8}";
		if(Pattern.matches(NameRegex, username)==false) {
		throw new BankException("Username start with capital letter");	
	}
	}

	@Override
	public void validatePassword(String password) throws BankException {
		String PasswordRegex="[0-9]{5}";
		if(Pattern.matches(PasswordRegex, password)==false) {
		throw new BankException("Password contains 5 digits");		
	}
	}

	@Override
	public void validateMobileNo(String mobileNo) throws BankException {
		String MobileRegex="[9|8|7]{1}[0-9]{9}";
		if(Pattern.matches(MobileRegex, mobileNo)==false) {
		throw new BankException("Mobile number should contains 10 digits");
		
	}

	}

	@Override
	public void validateAccount_number(int account_number) throws BankException {
		String AccountRegEx = "[0-9]+";
		if (Pattern.matches(AccountRegEx, String.valueOf(account_number)) == false) {
			throw new BankException("orderid should contain only digits");
		}

		
	}

	@Override
	public void ShowBalance(int account_number1) throws BankException {
		return dao.ShowBalance(account_number1);
		
	}
	}
