package com.cg.bank.service;

import com.cg.bank.exception.BankException;

public interface IBankService {

	void validateUserName(String username) throws BankException;

	void validatePassword(String password) throws BankException;

	void validateMobileNo(String mobileNo) throws BankException;

	void validateAccount_number(int account_number) throws BankException;

	char[] ShowBalance() throws BankException;

}
