package com.cg.bank.bean;

import java.time.LocalDate;

public class Transaction {
	private String Account_number;
	private Double Amount;
	LocalDate date;
	public Transaction(String account_number, Double amount, LocalDate date) {
		super();
		Account_number = account_number;
		Amount = amount;
		this.date = date;
	}
	public String getAccount_number() {
		return Account_number;
	}
	public void setAccount_number(String account_number) {
		Account_number = account_number;
	}
	public Double getAmount() {
		return Amount;
	}
	public void setAmount(Double amount) {
		Amount = amount;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Transaction [Account_number=" + Account_number + ", Amount=" + Amount + ", date=" + date + "]";
	}
	

}
