package com.cg.bank.dao;

public class BankDAOImpl implements IBankDAO {

	@Override
	public Object ShowBalance(int account_number1) {
		// TODO Auto-generated method stub
		return null;
	}

}
