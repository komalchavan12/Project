package com.cg.bank.dao;

import com.cg.bank.exception.BankException;

public interface IBankDAO {

	Object ShowBalance(int account_number1) throws BankException ;

}
